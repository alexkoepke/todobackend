"""Test data file with wrong encoding and if coding is not first line."""
# coding: utd-8 # [syntax-error]
STR = 'some text'
